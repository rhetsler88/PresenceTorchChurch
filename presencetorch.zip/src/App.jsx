import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { useEffect, useRef } from 'react';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import { appParams } from '@/lib/app-params';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import AppLayout from './components/layout/AppLayout';
import Talk from './pages/Talk';
import Contacts from './pages/Contacts';
import Channels from './pages/Channels';
import Transcripts from './pages/Transcripts';
import Monitor from './pages/Monitor';
import Admin from './pages/Admin';
import Onboarding from './pages/Onboarding';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin, user } = useAuth();
  const redirectingRef = useRef(false);

  // Only redirect to login in a useEffect (not during render) and only if
  // there is no token. If a token exists but auth failed, the user just signed
  // in via Google and is not registered — show the sign-up screen instead.
  useEffect(() => {
    if (authError?.type === 'auth_required' && !appParams.token && !redirectingRef.current) {
      redirectingRef.current = true;
      navigateToLogin();
    }
  }, [authError, navigateToLogin]);

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background dark">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
          <span className="text-sm text-muted-foreground font-medium">Connecting...</span>
        </div>
      </div>
    );
  }

  if (authError) {
    // If the user has a token (just signed in with Google) but any auth error
    // occurs, treat it as "not registered" — never redirect back to login.
    if (authError.type === 'user_not_registered' || appParams.token) {
      return <UserNotRegisteredError />;
    }
    // authError.type === 'auth_required' with no token — useEffect handles redirect
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background dark">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
          <span className="text-sm text-muted-foreground font-medium">Redirecting to sign in...</span>
        </div>
      </div>
    );
  }

  // Show onboarding for users who haven't completed it
  if (user && !user.onboarded) {
    return (
      <Routes>
        <Route path="/*" element={<Onboarding />} />
      </Routes>
    );
  }

  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route path="/" element={<Talk />} />
        <Route path="/contacts" element={<Contacts />} />
        <Route path="/channels" element={<Channels />} />
        <Route path="/transcripts" element={<Transcripts />} />
        <Route path="/monitor" element={<Monitor />} />
        <Route path="/admin" element={<Admin />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App