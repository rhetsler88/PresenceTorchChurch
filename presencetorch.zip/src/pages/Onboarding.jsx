import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Radio, Check, ArrowRight, ArrowLeft } from "lucide-react";
import { toast } from "sonner";

export default function Onboarding() {
  const { user, checkUserAuth } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [firstName, setFirstName] = useState(user?.full_name?.split(" ")[0] || "");
  const [lastName, setLastName] = useState(user?.full_name?.split(" ").slice(1).join(" ") || "");
  const [channels, setChannels] = useState([]);
  const [selectedChannels, setSelectedChannels] = useState(new Set());
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [organization, setOrganization] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const chans = await base44.entities.Channel.list("-created_date", 100);
        setChannels(chans);
      } catch (e) {
        toast.error("Couldn't load channels");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const toggleChannel = (id) => {
    setSelectedChannels(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const handleOrgSubmit = (e) => {
    e.preventDefault();
    if (!organization) {
      toast.error("Please select an organization");
      return;
    }
    setStep(2);
  };

  const handleStep1Submit = (e) => {
    e.preventDefault();
    if (!firstName.trim()) {
      toast.error("First name is required");
      return;
    }
    setStep(3);
  };

  const handleFinish = async () => {
    if (selectedChannels.size === 0) {
      toast.error("Please select at least one channel");
      return;
    }
    setSaving(true);
    try {
      await base44.auth.updateMe({
        first_name: firstName.trim(),
        last_name: lastName.trim(),
        organization,
        onboarded: true,
      });
      const userId = user?.id;
      if (userId) {
        await Promise.all(
          [...selectedChannels].map(cid => {
            const ch = channels.find(c => c.id === cid);
            if (!ch) return null;
            const pending = ch.pending_members || [];
            const approved = ch.members || [];
            if (!pending.includes(userId) && !approved.includes(userId)) {
              return base44.entities.Channel.update(cid, { pending_members: [...pending, userId] });
            }
            return null;
          }).filter(Boolean)
        );
      }
      await checkUserAuth();
      toast.success("Requests sent! Waiting for admin approval.");
      navigate("/");
    } catch (e) {
      toast.error("Couldn't complete onboarding");
      setSaving(false);
    }
  };

  return (
    <div className="min-h-dvh flex items-center justify-center p-4 bg-background safe-top">
      <div className="w-full max-w-md">
        <div className="flex items-center gap-2 mb-6">
          <div className={`flex-1 h-1 rounded-full ${step >= 1 ? "bg-primary" : "bg-muted"}`} />
          <div className={`flex-1 h-1 rounded-full ${step >= 2 ? "bg-primary" : "bg-muted"}`} />
          <div className={`flex-1 h-1 rounded-full ${step >= 3 ? "bg-primary" : "bg-muted"}`} />
        </div>

        <div className="bg-card border border-border rounded-2xl p-6">
          {step === 1 ? (
            <>
              <h1 className="text-xl font-bold text-foreground mb-1">Select your organization</h1>
              <p className="text-sm text-muted-foreground mb-5">Choose the organization or event you belong to.</p>
              <form onSubmit={handleOrgSubmit} className="space-y-3">
                {["Potter's House - Columbus"].map(org => {
                  const selected = organization === org;
                  return (
                    <button
                      key={org}
                      type="button"
                      onClick={() => setOrganization(org)}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border transition-all text-left ${
                        selected ? "bg-primary/10 border-primary/30" : "bg-muted/30 border-border hover:bg-muted/60"
                      }`}
                    >
                      <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 bg-primary/10">
                        <Radio className="w-4 h-4 text-primary" />
                      </div>
                      <span className="text-sm font-semibold text-foreground flex-1">{org}</span>
                      {selected && <Check className="w-4 h-4 text-primary" />}
                    </button>
                  );
                })}
                <Button type="submit" className="w-full gap-1.5">
                  Continue <ArrowRight className="w-4 h-4" />
                </Button>
              </form>
            </>
          ) : step === 2 ? (
            <>
              <h1 className="text-xl font-bold text-foreground mb-1">Welcome to PresencePoint</h1>
              <p className="text-sm text-muted-foreground mb-5">Let's set up your profile.</p>
              <form onSubmit={handleStep1Submit} className="space-y-4">
                <div>
                  <Label htmlFor="firstName">First name <span className="text-destructive">*</span></Label>
                  <Input id="firstName" value={firstName} onChange={e => setFirstName(e.target.value)} placeholder="Jane" required />
                </div>
                <div>
                  <Label htmlFor="lastName">Last name or initial</Label>
                  <Input id="lastName" value={lastName} onChange={e => setLastName(e.target.value)} placeholder="D or Doe" />
                </div>
                <Button type="submit" className="w-full gap-1.5">
                  Continue <ArrowRight className="w-4 h-4" />
                </Button>
              </form>
            </>
          ) : (
            <>
              <h1 className="text-xl font-bold text-foreground mb-1">Join a channel</h1>
              <p className="text-sm text-muted-foreground mb-5">Pick the channels you want to join. An admin will need to approve your request.</p>
              {loading ? (
                <div className="flex justify-center py-8">
                  <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                </div>
              ) : (
                <div className="space-y-2 max-h-72 overflow-y-auto">
                  {channels.map(ch => {
                    const selected = selectedChannels.has(ch.id);
                    return (
                      <button
                        key={ch.id}
                        type="button"
                        onClick={() => toggleChannel(ch.id)}
                        className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl border transition-all text-left ${
                          selected ? "bg-primary/10 border-primary/30" : "bg-muted/30 border-border hover:bg-muted/60"
                        }`}
                      >
                        <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: (ch.color || "#f59e0b") + "20" }}>
                          <Radio className="w-4 h-4" style={{ color: ch.color || "#f59e0b" }} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-foreground truncate">{ch.name}</p>
                        </div>
                        <div className={`w-5 h-5 rounded-md border flex items-center justify-center flex-shrink-0 ${selected ? "bg-primary border-primary" : "border-border"}`}>
                          {selected && <Check className="w-3.5 h-3.5 text-primary-foreground" />}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
              <div className="flex gap-2 mt-5">
                <Button variant="outline" onClick={() => setStep(2)} className="gap-1.5">
                  <ArrowLeft className="w-4 h-4" /> Back
                </Button>
                <Button onClick={handleFinish} disabled={saving || loading || selectedChannels.size === 0} className="flex-1">
                  {saving ? "Sending..." : `Request to join ${selectedChannels.size} channel${selectedChannels.size !== 1 ? "s" : ""}`}
                </Button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}